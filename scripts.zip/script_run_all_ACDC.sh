if [ -z "$1" ]
	then
	echo "Application's name is missing (#1)"
	exit 0
fi

./script_STIC.sh $1
./script_run_SDA_ACDC.sh $1
./script_run_MEA_ACDC.sh $1
./script_run_C2C_ACDC.sh $1
./script_run_BDMA_ACDC.sh $1
